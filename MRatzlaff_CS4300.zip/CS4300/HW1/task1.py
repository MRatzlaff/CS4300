# task 1: print Hello World to console
def hello_world():
    print("Hello, World!")



