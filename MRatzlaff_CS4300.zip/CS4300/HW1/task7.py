# task 7
import numpy as np 
# demonstrate use of numpy

#add
def add_with_numpy(n1, n2):
    return np.add(n1, n2)


#subtract
def sub_with_numpy(n1, n2):
    return np.subtract(n1, n2)


#multiply
def mult_with_numpy(n1, n2):
    return np.multiply(n1, n2)