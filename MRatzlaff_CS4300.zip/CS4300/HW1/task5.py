# task 5

# slice first three books from list
fave_books = ["The Lacuna by Barbara Kingsolver", 
    "My Name is Asher Lev by Chaim Potok", "Ninth Street Women by Mary Gabriel", 
    "The Dutch House by Ann Patchett", "The Secret History by Donna Tartt"]

def slice_books():
    return fave_books[:3] # returns positions 1-3 (not 0 based) of list


# dictionary of student database: name and student ID
student_database = {"Ross Geller": 393249, "Monica Geller": 284932, 
    "Phoebe Buffay": 842390, "Chandler Bing": 437295, "Joey Tribbiani": 902347}


