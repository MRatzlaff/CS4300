# task 2: demonstrate the use of data types

def int_():
    integer_tester = 3
    return integer_tester


def float_():
    float_tester = 2.537
    return float_tester


def string_():
    string_tester = "I love engineering"
    return string_tester


def bool_true():
    boolean_true_tester = True
    return boolean_true_tester


def bool_false(): 
    boolean_false_tester = False
    return boolean_false_tester
