# task 4

# multiply original price by discount and return final price
def calculate_discount(price, discount):
    final_price = price * discount
    return final_price